package com.example.student.service;

public class StudentService {

}
