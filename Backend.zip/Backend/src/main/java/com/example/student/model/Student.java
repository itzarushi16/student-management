package com.example.student.model;

public class Student {

}
