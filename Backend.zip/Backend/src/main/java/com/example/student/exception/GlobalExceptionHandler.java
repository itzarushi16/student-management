package com.example.student.exception;

public class GlobalExceptionHandler {

}
