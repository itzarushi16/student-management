package com.example.student.repository;

public class StudentRepository {

}
