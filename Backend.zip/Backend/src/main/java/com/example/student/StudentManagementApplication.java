package com.example.student;

public class StudentManagementApplication {

}
