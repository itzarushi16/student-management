package com.example.student.config;

public class WebConfig {

}
