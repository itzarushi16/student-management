package com.example.student.controller;

public class StudentController {

}
